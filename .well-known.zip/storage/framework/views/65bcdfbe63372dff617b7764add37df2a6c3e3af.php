

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">Edit Hobby</div>
                    <div class="card-body">
                        <form action="/hobby/<?php echo e($hobby->id); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>
                            <div class="form-group">
                                <label for="name">Name</label>
                                <input type="text" class="form-control<?php echo e($errors->has('name') ? ' border-danger' : ''); ?>" id="name" name="name" value="<?php echo e($hobby->name ?? old('name')); ?>">
                                <small class="form-text text-danger"><?php echo $errors->first('name'); ?></small>
                            </div>
                            <div class="form-group">
                                <label for="description">Description</label>
                                <textarea class="form-control<?php echo e($errors->has('description') ? ' border-danger' : ''); ?>" id="description" name="description" rows="5"><?php echo e($hobby->description ?? old('description')); ?></textarea>
                                <small class="form-text text-danger"><?php echo $errors->first('description'); ?></small>
                            </div>
                            <input class="btnbtn-dark mt-4" type="submit" value="Save Hobby">
                        </form>
                        <a class="btnbtn-dark float-right" href="/hobby"><i class="fas fa-arrow-circle-up"></i> Back</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Kwesi\Videos\Laravel Projectsa\hobbies\resources\views/hobby/edit.blade.php ENDPATH**/ ?>