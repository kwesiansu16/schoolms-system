

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">Create New Tag</div>
                    <div class="card-body">
                        <form action="/tag" method="POST">
                            <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <label for="name">Name</label>
                                <input type="text" class="form-control<?php echo e($errors->has('name') ? ' border-danger' : ''); ?>" id="name" name="name" value="<?php echo e(old('name')); ?>">
                                <small class="form-text text-danger"><?php echo $errors->first('name'); ?></small>
                            </div>
                            <div class="form-group">
                                <label for="description">Style</label>
                                <textarea class="form-control<?php echo e($errors->has('style') ? ' border-danger' : ''); ?>" id="style" name="style" rows="5"><?php echo e(old('style')); ?></textarea>
                                <small class="form-text text-danger"><?php echo $errors->first('style'); ?></small>
                            </div>
                            <input class="btnbtn-dark mt-4" type="submit" value="Save Tag">
                        </form>
                        <a class="btnbtn-dark float-right" href="/tag"><i class="fas fa-arrow-circle-up"></i> Back</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Kwesi\Videos\Laravel Projectsa\hobbies\resources\views/tag/create.blade.php ENDPATH**/ ?>