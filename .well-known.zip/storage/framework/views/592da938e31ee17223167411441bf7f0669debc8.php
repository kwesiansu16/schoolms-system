

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Details</div>

                <div class="card-body">
                  <b><?php echo e($hobby->name); ?></b>
                  
                 <p><?php echo e($hobby->description); ?></p>
                  
                </div>
            </div>

            <div class="mt-2">
                <a class="btnbtn-dark btn-sm" href="/hobby"><i class="fa fa-angle-left" aria-hidden="true"></i>
                    Back to overview</a>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Kwesi\Videos\Laravel Projectsa\hobbies\resources\views/hobby/show.blade.php ENDPATH**/ ?>