

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Tag List</div>

                <div class="card-body">
                   <ul class="list-group">
                       <?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                       <li class="list-group-item">
                           <?php echo e($tag->name); ?>

                           <div class="col-md-12 bg-light text-right">
                           <a href="/tag/<?php echo e($tag->id); ?>"><button type="button" class="btnbtn-dark">Details</button></a>
                           <a href="/tag/<?php echo e($tag->id); ?>/edit"><button type="button" class="btnbtn-dark">Edit</button></a>
                           <form method="post" style="margin-left:5px;" class="float-right" action="/tag/<?php echo e($tag->id); ?>">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('Delete'); ?>
                            <input type="submit" class="btn btn-md-12 btn-danger" value="Delete">

                           </form>
                 
                        </div>
                       </li>
                      
                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                   </ul>
                </div>
            </div>

            <div class="mt-2">
                <a class="btn btn-success btn-sm" href="/tag/create"><i class="fa fa-plus-circle" aria-hidden="true"></i>Create new tag</a>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Kwesi\Videos\Laravel Projectsa\hobbies\resources\views/tag/index.blade.php ENDPATH**/ ?>