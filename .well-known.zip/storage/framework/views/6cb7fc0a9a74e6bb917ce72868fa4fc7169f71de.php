

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">All hobbies <?php echo e($hobbies->count()); ?></div>

                <div class="card-body">
                   <ul class="list-group">
                       <?php $__currentLoopData = $hobbies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hobby): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                       <li class="list-group-item">
                           <?php echo e($hobby->name); ?>

                           <div class="col-md-12 bg-light text-right">
                            <span><?php echo e($hobby->created_at->diffForHumans()); ?></span>
                           <a href="/hobby/<?php echo e($hobby->id); ?>"><button type="button" class="btnbtn-dark">Details</button></a>
                           <?php if(auth()->guard()->check()): ?>
                           <a href="/hobby/<?php echo e($hobby->id); ?>/edit"><button type="button" class="btnbtn-dark">Edit</button></a>
                           <form method="post" style="margin-left:5px;" class="float-right" action="/hobby/<?php echo e($hobby->id); ?>">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('Delete'); ?>
                            <input type="submit" class="btn btn-md-12 btn-danger" value="Delete">
                           

                           </form>
                           <?php endif; ?>
                 
                        </div>
                       </li>
                      
                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                   </ul>
                </div>
            </div>

            <div class="mt-3">
                <?php echo e($hobbies->links()); ?>

            </div>

            <div class="mt-2">
                <a class="btn btn-success btn-sm" href="/hobby/create"><i class="fa fa-plus-circle" aria-hidden="true"></i>Create new hobby</a>
                <a class="btnbtn-dark btn-sm" href="<?php echo e(URL::previous()); ?>"><i class="fas fa-arrow-circle-up"></i> Back to Overview</a>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Kwesi\Videos\Laravel Projectsa\hobbies\resources\views/hobby/index.blade.php ENDPATH**/ ?>