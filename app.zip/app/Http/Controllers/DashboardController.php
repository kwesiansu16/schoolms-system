<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
use App\Scholar;


class DashboardController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */

    public function __construct()
    {
        $this->middleware('auth')->except(['index', 'show']);
    }


    public function dashboard1(){
        $scholar = DB::table('scholars')->count();
        $instructor = DB::table('instructors')->count();
        $program = DB::table('programs')->count();
        $sum_fees = DB::table('fees')->sum('amount');
        return view('dashboard1.dashboard',compact('scholar','instructor','program','sum_fees'));
    }


      
      
    


    /*public function dashboard1(){
        // $hobbies = Hobby::all();
        //$hobbies = Hobby::paginate(5);
        
         return view('dashboard1.dashboard');
     }
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show()
    {
        //
       
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
